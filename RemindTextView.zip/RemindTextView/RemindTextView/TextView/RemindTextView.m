//
//  RemindTextView.m
//  RemindTextView
//
//  Created by ekey on 2018/9/5.
//  Copyright © 2018年 ekey. All rights reserved.
//
#define Screen_height [[UIScreen mainScreen] bounds].size.height
#define Screen_width [[UIScreen mainScreen] bounds].size.width

#define INTERVAL_KEYBOARD 20//提醒框到键盘的距离

#import "RemindTextView.h"
#import "UITextView+Placeholder.h"
#import "SVProgressHUD.h"

@interface RemindTextView()<UITextViewDelegate>
@property(strong,nonatomic) UIView *remindBgView;
@property(strong,nonatomic) UILabel *titleLabel;
@property(strong,nonatomic) UITextView *textView;
@property(strong,nonatomic) UILabel *stringLenghLabel;
@property(strong,nonatomic) UIButton *cancelBtn;
@property(strong,nonatomic) UIButton *sureBtn;

@property(copy,  nonatomic) NSString *warning;
@property(assign,nonatomic) int limit;

@end

@implementation RemindTextView
-(instancetype)initWithController:(UIViewController*)controller{
    self = [super init];
    if (self) {
        self.frame = [UIApplication sharedApplication].windows.firstObject.frame;
        self.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:0.3];
        [controller.view addSubview:self];
        self.limit = 0;
        [self configUI];
        [self addObserverForKeyboard];
    }
    
    return self;
}

-(void)configUI{
    self.remindBgView = [[UIView alloc]initWithFrame:CGRectMake(25,(Screen_height-263)/2, Screen_width-50, 263)];
    self.remindBgView.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.remindBgView];
    self.remindBgView.layer.cornerRadius=15;
    [self.remindBgView.layer setMasksToBounds:YES];
    CGFloat remindBgView_width = Screen_width-50;
    
    self.titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 15, remindBgView_width, 20)];
    self.titleLabel.text = @"提示";
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.font = [UIFont systemFontOfSize:14];
    [self.remindBgView addSubview:self.titleLabel];
    
    self.textView = [[UITextView alloc]initWithFrame:CGRectMake(20, 45, remindBgView_width-40, 140)];
    self.textView.delegate = self;
    self.textView.font = [UIFont systemFontOfSize:14];
    self.textView.layer.borderWidth = 1;
    self.textView.layer.borderColor = [UIColor grayColor].CGColor;
    [self.remindBgView addSubview:self.textView];
    
    
    UILabel *liner = [[UILabel alloc]initWithFrame:CGRectMake(0, 209, remindBgView_width, 1)];
    liner.backgroundColor = [UIColor grayColor];
    [self.remindBgView addSubview:liner];
    
    UILabel *seperateLine=[[UILabel alloc]initWithFrame:CGRectMake(remindBgView_width/2-1, 209, 1, 53)];
    seperateLine.backgroundColor=[UIColor grayColor];
    [self.remindBgView addSubview:seperateLine];
    
    self.cancelBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    self.cancelBtn.frame=CGRectMake(0,210,remindBgView_width/2,53);
    [self.cancelBtn setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [self.cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
    self.cancelBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [self.cancelBtn addTarget:self action:@selector(clickCancel:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.remindBgView addSubview:self.cancelBtn];
    
    self.sureBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    self.sureBtn.frame=CGRectMake(remindBgView_width/2,210,remindBgView_width/2,53);
    [self.sureBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [self.sureBtn setTitle:@"确认" forState:UIControlStateNormal];
    self.sureBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [self.sureBtn addTarget:self action:@selector(clickSureBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self.remindBgView addSubview:self.sureBtn];
}


-(void)clickSureBtn:(id)sender{
    if (self.warning) {
        if (!self.textView.text.length) {
            [SVProgressHUD showInfoWithStatus:self.warning];
            return;
        }
    }
    if (self.requestDataBlock) {
        self.requestDataBlock(self.textView.text);
    }
    [self remindViewClose];
    
}

-(void)clickCancel:(id)sender{
     [self remindViewClose];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    if ([touches anyObject].view == self) {
        [self remindViewClose];
    }
}

//关闭提醒框
-(void)remindViewClose{
    [UIView animateWithDuration:0.5 animations:^{
        
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

#pragma mark - 键盘通知
-(void)addObserverForKeyboard{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

-(void)keyboardWillShow:(NSNotification *)notification{
    NSDictionary *dict = notification.userInfo;
    //获取键盘高度，在不同设备上，以及中英文下是不同的
    CGFloat keyboardHeight = [[dict objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    CGFloat offset = (Screen_height - keyboardHeight)  - (self.remindBgView.frame.size.height + INTERVAL_KEYBOARD);
    
     // 取得键盘的动画时间，这样可以在视图上移的时候更连贯
    double duration = [[dict objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    if (offset>0) {
        [UIView animateWithDuration:duration animations:^{
            self.remindBgView.frame = CGRectMake(25, offset, self.remindBgView.frame.size.width, self.remindBgView.frame.size.height);
        }];
    }
}

-(void)keyboardWillHide:(NSNotification *)notification{
    // 键盘动画时间
    double duration = [[notification.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    //视图下沉恢复原状
    [UIView animateWithDuration:duration animations:^{
        self.remindBgView.frame = CGRectMake(25, (Screen_height-263)/2, Screen_width-50, 263);
    }];
}

#pragma mark -UITextViewDelegate
-(void)textViewDidChange:(UITextView *)textView{
    if (self.limit) {
        self.stringLenghLabel.text = [NSString stringWithFormat:@"%ld", (self.limit-textView.text.length)];
        if(textView.text.length>=self.limit){
            textView.text=[textView.text substringToIndex:self.limit];
            self.stringLenghLabel.text = @"0";
        }
    }
   
}


#pragma mark - 接口
+(instancetype)showWithController:(UIViewController*)controller{
    RemindTextView *textView = [[RemindTextView alloc]initWithController:controller];
    return textView;
}

+(instancetype)showWithController:(UIViewController*)controller andRequestDataBlock:(void(^)(NSString *text))requestDataBlock{
    RemindTextView *textView = [[RemindTextView alloc]initWithController:controller];
    textView.requestDataBlock = requestDataBlock;
    return textView;
}

+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title{
    RemindTextView *textView = [[RemindTextView alloc]initWithController:controller];
    if (title) {
        textView.titleLabel.text = title;
    }
    return textView;
}


+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title andRequestDataBlock:(void(^)(NSString *text))requestDataBlock{
    RemindTextView *textView = [[RemindTextView alloc]initWithController:controller];
    if (title) {
        textView.titleLabel.text = title;
    }
    textView.requestDataBlock = requestDataBlock;
    return textView;
}

+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit{
    RemindTextView *view = [[RemindTextView alloc]initWithController:controller];
    if (title) {
        view.titleLabel.text = title;
    }
    if (warning) {
        view.textView.placeholder = warning;
    }
    
    if (limit) {
        view.stringLenghLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,165,Screen_width-0,20)];
        view.stringLenghLabel.textAlignment = NSTextAlignmentRight;
        view.stringLenghLabel.text = [NSString stringWithFormat:@"%d",limit];
        view.stringLenghLabel.textColor = [UIColor lightGrayColor];
        view.stringLenghLabel.font = [UIFont systemFontOfSize:12];
        [view.remindBgView addSubview:view.stringLenghLabel];
        view.limit = limit;
    }
   
    return view;
    

}

+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit andRequestDataBlock:(void(^)(NSString *text))requestDataBlock{
    RemindTextView *view = [[RemindTextView alloc]initWithController:controller];
    if (title) {
        view.titleLabel.text = title;
    }
    if (warning) {
        view.textView.placeholder = warning;
        view.warning = warning;
    }
    
    if (limit) {
        view.stringLenghLabel = [[UILabel alloc]initWithFrame:CGRectMake(20,165,Screen_width-90,20)];
        view.stringLenghLabel.textAlignment = NSTextAlignmentRight;
        view.stringLenghLabel.textColor = [UIColor lightGrayColor];
        view.stringLenghLabel.font = [UIFont systemFontOfSize:12];
        view.stringLenghLabel.text = [NSString stringWithFormat:@"%d",limit];
        [view.remindBgView addSubview:view.stringLenghLabel];
        view.limit = limit;
    }
     view.requestDataBlock = requestDataBlock;
    return view;
}

+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit text:(NSString*)text{
    RemindTextView *view = [[RemindTextView alloc]initWithController:controller];
    if (title) {
        view.titleLabel.text = title;
    }
    if (warning) {
        view.textView.placeholder = warning;
        view.warning = warning;
    }
    
    if (limit) {
        view.stringLenghLabel = [[UILabel alloc]initWithFrame:CGRectMake(20,165,Screen_width-90,20)];
        view.stringLenghLabel.textAlignment = NSTextAlignmentRight;
        view.stringLenghLabel.textColor = [UIColor lightGrayColor];
        view.stringLenghLabel.font = [UIFont systemFontOfSize:12];
        view.stringLenghLabel.text = [NSString stringWithFormat:@"%d",limit];
        [view.remindBgView addSubview:view.stringLenghLabel];
        view.limit = limit;
    }
    if (text) {
        view.textView.text = text;
    }
    return view;
}

+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit text:(NSString*)text andRequestDataBlock:(void(^)(NSString *text))requestDataBlock{
    RemindTextView *view = [[RemindTextView alloc]initWithController:controller];
    if (title) {
        view.titleLabel.text = title;
    }
    if (warning) {
        view.textView.placeholder = warning;
        view.warning = warning;
    }
    
    if (limit) {
        view.stringLenghLabel = [[UILabel alloc]initWithFrame:CGRectMake(20,165,Screen_width-90,20)];
        view.stringLenghLabel.textAlignment = NSTextAlignmentRight;
        view.stringLenghLabel.textColor = [UIColor lightGrayColor];
        view.stringLenghLabel.font = [UIFont systemFontOfSize:12];
        view.stringLenghLabel.text = [NSString stringWithFormat:@"%d",limit];
        [view.remindBgView addSubview:view.stringLenghLabel];
        view.limit = limit;
    }
    if (text) {
        view.textView.text = text;
    }
    view.requestDataBlock = requestDataBlock;
    return view;
}

+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit text:(NSString*)text cancelBtnTitle:(NSString*)cancelBtnTitle sureBtnTitle:(NSString*)sureBtnTitle{
    RemindTextView *view = [[RemindTextView alloc]initWithController:controller];
    if (title) {
        view.titleLabel.text = title;
    }
    if (warning) {
        view.textView.placeholder = warning;
        view.warning = warning;
    }
    
    if (limit) {
        view.stringLenghLabel = [[UILabel alloc]initWithFrame:CGRectMake(20,165,Screen_width-90,20)];
        view.stringLenghLabel.textAlignment = NSTextAlignmentRight;
        view.stringLenghLabel.textColor = [UIColor lightGrayColor];
        view.stringLenghLabel.font = [UIFont systemFontOfSize:12];
        view.stringLenghLabel.text = [NSString stringWithFormat:@"%d",limit];
        [view.remindBgView addSubview:view.stringLenghLabel];
        view.limit = limit;
    }
    if (text) {
        view.textView.text = text;
    }
    if (cancelBtnTitle) {
        [view.cancelBtn setTitle:cancelBtnTitle forState:UIControlStateNormal];
    }
    if (sureBtnTitle) {
        [view.sureBtn setTitle:sureBtnTitle forState:UIControlStateNormal];
    }
    return view;
}

+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit text:(NSString*)text cancelBtnTitle:(NSString*)cancelBtnTitle sureBtnTitle:(NSString*)sureBtnTitle andRequestDataBlock:(void(^)(NSString *text))requestDataBlock{
    RemindTextView *view = [[RemindTextView alloc]initWithController:controller];
    if (title) {
        view.titleLabel.text = title;
    }
    if (warning) {
        view.textView.placeholder = warning;
        view.warning = warning;
    }
    
    if (limit) {
        view.stringLenghLabel = [[UILabel alloc]initWithFrame:CGRectMake(20,165,Screen_width-90,20)];
        view.stringLenghLabel.textAlignment = NSTextAlignmentRight;
        view.stringLenghLabel.textColor = [UIColor lightGrayColor];
        view.stringLenghLabel.font = [UIFont systemFontOfSize:12];
        view.stringLenghLabel.text = [NSString stringWithFormat:@"%d",limit];
        [view.remindBgView addSubview:view.stringLenghLabel];
        view.limit = limit;
    }
    if (text) {
        view.textView.text = text;
    }
    if (cancelBtnTitle) {
        [view.cancelBtn setTitle:cancelBtnTitle forState:UIControlStateNormal];
    }
    if (sureBtnTitle) {
        [view.sureBtn setTitle:sureBtnTitle forState:UIControlStateNormal];
    }
    view.requestDataBlock = requestDataBlock;
    return view;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
