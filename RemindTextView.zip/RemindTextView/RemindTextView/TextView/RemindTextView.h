//
//  RemindTextView.h
//  RemindTextView
//
//  Created by ekey on 2018/9/5.
//  Copyright © 2018年 ekey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RemindTextView : UIView
@property(nonatomic,copy) void(^requestDataBlock)(NSString *text);

/**
 显示默认的提醒框(标题为提示，textView里面空白，没有字数限制，按钮为取消、确定)

 @param controller 控制器
 @return 提醒框
 */
+(instancetype)showWithController:(UIViewController*)controller;

/**
  显示默认的提醒框(标题为提示，textView里面空白，没有字数限制，按钮为取消、确定)

 @param controller 控制器
 @param requestDataBlock 按下确定处理的block
 @return 提醒框
 */
+(instancetype)showWithController:(UIViewController*)controller andRequestDataBlock:(void(^)(NSString *text))requestDataBlock;

/**
 提醒框标题可设置，其余默认(textView里面空白，没有字数限制，按钮为取消、确定)

 @param controller 控制器
 @param title 标题，设置nil则标题为默认的“提示”
 @return 提醒框
 */
+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title;

/**
  提醒框标题可设置，其余默认(textView里面空白，没有字数限制，按钮为取消、确定)

 @param controller 控制器
 @param title 标题，设置nil则标题为默认的“提示”
 @param requestDataBlock 按下确定处理的block
 @return 提醒框
 */
+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title andRequestDataBlock:(void(^)(NSString *text))requestDataBlock;

/**
 提醒框标题可设置，textView的placeholder设置为warning，字数限制为limit，其余默认(按钮为取消、确定)
textView的字数为零时，提示warning且提醒框不消失
 
 @param controller 控制器
 @param title 标题，设置nil则标题为默认的“提示”
 @param warning 警告，设置nil则没有placeholder和提示
 @param limit 字数，设置0则没有字数限制
 @return 提醒框
 */
+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit;

/**
 提醒框标题可设置，textView的placeholder设置为warning，字数限制为limit，其余默认(按钮为取消、确定)
 textView的字数为零时，提示warning且提醒框不消失
 
 @param controller 控制器
 @param title 标题，设置nil则标题为默认的“提示”
 @param warning 警告，设置nil则没有placeholder和提示
 @param limit 字数，设置0则没有字数限制
 @param requestDataBlock 按下确定处理的block
 @return 提醒框
 */
+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit andRequestDataBlock:(void(^)(NSString *text))requestDataBlock;

/**
 提醒框标题可设置，textView的placeholder设置为warning，textView初始化文字为text，字数限制为limit，其余默认(按钮为取消、确定)
textView的字数为零时，提示warning且提醒框不消失
 @param controller 控制器
 @param title 标题，设置nil则标题为默认的“提示”
 @param warning 警告，设置nil则没有placeholder和提示
 @param limit 字数，设置0则没有字数限制
 @param text 文字，设置nil则textView没有初始化的文字
 @return 提醒框
 */
+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit text:(NSString*)text;

/**
 提醒框标题可设置，textView的placeholder设置为warning，textView初始化文字为text，字数限制为limit，其余默认(按钮为取消、确定)
 textView的字数为零时，提示warning且提醒框不消失
 @param controller 控制器
 @param title 标题，设置nil则标题为默认的“提示”
 @param warning 警告，设置nil则没有placeholder和提示
 @param limit 字数，设置0则没有字数限制
 @param text 文字，设置nil则textView没有初始化的文字
@param requestDataBlock 按下确定处理的block
 @return 提醒框
 */
+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit text:(NSString*)text andRequestDataBlock:(void(^)(NSString *text))requestDataBlock;

/**
 提醒框标题可设置，textView的placeholder设置为warning，textView初始化文字为text，字数限制为limit，取消按钮的标题为cancelBtnTitle，确定按钮的标题为sureBtnTitle
 textView的字数为零时，提示warning且提醒框不消失

 @param controller 控制器
 @param title 标题，设置nil则标题为默认的“提示”
 @param warning 警告，设置nil则没有placeholder和提示
 @param limit 字数，设置0则没有字数限制
 @param text 文字，设置nil则textView没有初始化的文字
 @param cancelBtnTitle 取消按钮标题，为nil默认为“取消”
 @param sureBtnTitle 确定按钮标题 为nil默认为“确定”
 @return 提醒框
 */
+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit text:(NSString*)text cancelBtnTitle:(NSString*)cancelBtnTitle sureBtnTitle:(NSString*)sureBtnTitle;

/**
 提醒框标题可设置，textView的placeholder设置为warning，textView初始化文字为text，字数限制为limit，取消按钮的标题为cancelBtnTitle，确定按钮的标题为sureBtnTitle
 textView的字数为零时，提示warning且提醒框不消失
 
 @param controller 控制器
 @param title 标题，设置nil则标题为默认的“提示”
 @param warning 警告，设置nil则没有placeholder和提示
 @param limit 字数，设置0则没有字数限制
 @param text 文字，设置nil则textView没有初始化的文字
 @param cancelBtnTitle 取消按钮标题，为nil默认为“取消”
 @param sureBtnTitle 确定按钮标题 为nil默认为“确定”
 @param requestDataBlock 按下确定处理的block
 @return 提醒框
 */
+(instancetype)showWithController:(UIViewController*)controller title:(NSString*)title warning:(NSString*)warning limit:(int)limit text:(NSString*)text cancelBtnTitle:(NSString*)cancelBtnTitle sureBtnTitle:(NSString*)sureBtnTitle andRequestDataBlock:(void(^)(NSString *text))requestDataBlock;
@end
