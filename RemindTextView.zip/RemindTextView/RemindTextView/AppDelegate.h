//
//  AppDelegate.h
//  RemindTextView
//
//  Created by ekey on 2018/9/5.
//  Copyright © 2018年 ekey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

