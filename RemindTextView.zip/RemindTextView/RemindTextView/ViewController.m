//
//  ViewController.m
//  RemindTextView
//
//  Created by ekey on 2018/9/5.
//  Copyright © 2018年 ekey. All rights reserved.
//

#import "ViewController.h"
#import "RemindTextView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.backgroundColor = [UIColor redColor];
    btn.frame = CGRectMake(self.view.frame.origin.x+100, self.view.frame.origin.y+100, 100, 30);
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

-(void)btnClick{
//    [RemindTextView showWithController:self andRequestDataBlock:^(NSString *text) {
//        NSLog(@"textView:%@",text);
//    }];
//    [RemindTextView showWithController:self title:@"请输入拒绝原因" andRequestDataBlock:^(NSString *text) {
//        NSLog(@"textView:%@",text);
//    }];
    
//    [RemindTextView showWithController:self title:@"请输入拒绝原因" warning:@"请输入拒绝原因" limit:100 andRequestDataBlock:^(NSString *text) {
//        NSLog(@"textView:%@",text);
//    }];
//
//    [RemindTextView showWithController:self title:@"请输入拒绝原因" warning:@"请输入拒绝原因" limit:50 text:@"的阿宝感觉好" cancelBtnTitle:@"不填写继续" sureBtnTitle:@"eh"];
    [RemindTextView showWithController:self title:nil warning:@"请输入拒绝原因" limit:10 text:nil cancelBtnTitle:nil sureBtnTitle:nil andRequestDataBlock:^(NSString *text) {
        NSLog(@"textView:%@",text);
    }];
//    [RemindTextView showWithController:self title:@"请输入拒绝原因" warning:@"请输入拒绝原因" limit:300 text:@"的阿宝感觉好" andRequestDataBlock:^(NSString *text) {
//        NSLog(@"textView:%@",text);
//    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
